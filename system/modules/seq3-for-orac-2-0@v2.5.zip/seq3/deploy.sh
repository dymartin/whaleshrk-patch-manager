oscsend localhost 4001 /oled/aux/line/2 s "installing"
oscsend localhost 4001 /oled/aux/line/3 s "orac module: seq3"
cd ..
mv $1 orac/modules/sequence
exit 1
